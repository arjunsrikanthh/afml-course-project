# IEEE conference paper

`AFML_IEEE_Paper.pdf` is the compiled paper. `AFML_IEEE_Paper.tex` is the editable LaTeX source. The three authors are Arjun Srikanth, Ankit Umadi and Jayanth K. No individual contributions are inferred.

The class is the authentic IEEEtran 1.8b conference class, downloaded from CTAN on 15 November 2026. Source: https://ctan.org/pkg/ieeetran and https://mirrors.ctan.org/macros/latex/contrib/IEEEtran/IEEEtran.cls . Its copyright and license notices are retained in `IEEEtran.cls`.

Compile from this directory with `tectonic AFML_IEEE_Paper.tex`, or run `pdflatex AFML_IEEE_Paper.tex` twice. The two vector PDF figures and generated results table are included, so compilation does not require the experiment environment. `build_figures.py` regenerates those assets from the project workspace's retained metric CSVs; it requires Python, pandas and matplotlib. For a portable repository layout, use `python build_figures.py --results-root /path/to/results` with `reference/` and `expanded/` subdirectories, each containing the metric tables directly or in an `evaluation/` directory.

The paper reports the six-city experiment, distinguishes that cohort from the larger acquired archive, and preserves the negative fine-tuning and meta-learning results. It makes no publication, acceptance, national-generalization or deployment claim.

## Owning evidence

Paths below are relative to the AFML project root.

- Source inventory and cohort: `results/final_study_20261114/mac_research/afml_research/data/data_summary.json`, `protocol.json`, `cohort.csv` and `evaluation/eligibility_counts.csv`.
- Expanded metrics and paired intervals: `results/final_study_20261114/mac_research/afml_research/evaluation/macro_metrics.csv` and `paired_comparisons.csv`.
- Compact metrics: `results/final_study_20261114/mac_models/afml_final/evaluation/macro_metrics.csv`.
- Strict proposal criterion: `results/final_study_20261114/local_final_synthesis/original_proposal_success_conditions.csv` (45 compact and 54 expanded cells).
- Temporal sensitivity: `results/final_study_20261114/local_final_synthesis/paired_2024_2025_comparison.csv`.
- Exact implementation: `results/final_study_20261114/mac_research/afml_research_source/scripts/final_model_engine.py`, `research_model_engine.py` and `final_evaluation.py`.
- Audit: `results/final_study_20261114/independent_reference_audit/verification.json` and `independent_research_audit/verification.json`. These establish artifact consistency and chronology, with the audit limits explicitly stated in the paper.

`numeric_evidence.json` contains the metric records used for the paper's principal table and matched-meta discussion. Main comparisons use the 2025 test; 2024 is a separate evaluation year, never validation or tuning.

## Reference checks

Primary bibliographic sources were inspected on 15 November 2026:

- CPCB portal and official AQI report: https://airquality.cpcb.gov.in/ccr/ and https://airquality.cpcb.gov.in/ccr_docs/FINAL-REPORT_AQI_.pdf . The source snapshot is established by retained acquisition evidence; this paper build did not reacquire the archive or certify current file listings. Current repository route: https://airquality.cpcb.gov.in/ccr/#/repository/aqi .
- RegionTrans: https://ijcai.org/proceedings/2019/262 (crowd-flow demonstration, not an Indian AQI result).
- PM10 transfer: https://www.nature.com/articles/s41598-025-86550-6 (publisher-indexed metadata and full-text search excerpts; direct full-text page redirected to an inaccessible identity endpoint).
- GRU: https://aclanthology.org/D14-1179/ .
- LSTM: https://www.bioinf.jku.at/publications/older/2604.pdf (author-institution-hosted paper; MIT publisher URL returned 403).
- TCN: https://arxiv.org/abs/1803.01271 .
- Transformer: https://papers.nips.cc/paper_files/paper/2017/hash/3f5ee243547dee91fbd053c1c4a845aa-Abstract.html .
- MAML: https://proceedings.mlr.press/v70/finn17a.html .
- FOMAML/Reptile: https://arxiv.org/abs/1803.02999 .

No new literature claim of novelty is made. In-text references use normal IEEE numbering.
